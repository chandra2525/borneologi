<?php

require_once '../../app/config/database.php';
require_once '../../app/controllers/UserController.php';
require_once '../../app/core/session.php';
require_once '../../app/core/csrf.php';
require_once "../../app/core/auth.php";
require_once '../../app/helpers/escape.php';
require_once "../../app/core/permission.php";

secureSessionStart();
checkAuth("non_dashboard");

$controller = new UserController($pdo);
$users = $controller->index();
$roles = $controller->getRoles();
Permission::authorize($pdo, 'Pengguna', 'view');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Borneologi</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/fontawesome-free/css/all.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../assets/adminlte/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include "../feature/navbar.php" ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php
        $menu = "user";
        include "../feature/sidebar.php";
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 data-translate="Data Pengguna">Data Pengguna</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#" data-translate="Master Data">Master Data</a></li>
                                <li class="breadcrumb-item active" data-translate="Data Pengguna">Data Pengguna</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header row">
                                    <h3 class="card-title col-9"
                                        data-translate="Berikut adalah list dari Data Pengguna">
                                        Berikut adalah list dari Data Pengguna
                                    </h3>
                                    <!-- <h3 class="card-title col-9" id="deskripsiMenu">Berikut adalah list dari Data Pengguna</h3> -->
                                    <!-- <a href="create.php" class="col-2 btn btn-block btn-success">Tambah Pengguna</a> -->
                                    <?php if (Permission::can($pdo, 'Pengguna', 'create')): ?>
                                        <button class="col-3 btn btn-block btn-success" data-toggle="modal"
                                            data-target="#modalTambah" data-translate="Tambah Pengguna">
                                            Tambah Pengguna
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th data-translate="Nama Lengkap">Nama Lengkap</th>
                                                <th data-translate="Username">Username</th>
                                                <th data-translate="Email">Email</th>
                                                <th data-translate="No HP">No HP</th>
                                                <th data-translate="Role">Role</th>
                                                <th data-translate="Status Aktif">Status Aktif</th>
                                                <th data-translate="Aksi">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1; ?>
                                            <?php foreach ($users as $user): ?>
                                                <tr>
                                                    <td class="text-center"><?= $no++ ?></td>
                                                    <td><?= e($user['nama_lengkap']) ?></td>
                                                    <td><?= e($user['username']) ?></td>
                                                    <td><?= e($user['email']) ?></td>
                                                    <td><?= e($user['nomor_hp']) ?></td>
                                                    <td><?= e($user['role_name']) ?></td>
                                                    <td><?= $user['is_active'] ? "Aktif" : "Nonaktif" ?></td>
                                                    <td class="row">
                                                        <?php if (Permission::can($pdo, 'Pengguna', 'update')): ?>
                                                            <div class="col">
                                                                <button class="btn btn-block btn-info btn-edit"
                                                                    data-id="<?= $user['id'] ?>"
                                                                    data-username="<?= e_attr($user['username']) ?>"
                                                                    data-email="<?= e_attr($user['email']) ?>"
                                                                    data-nama_lengkap="<?= e_attr($user['nama_lengkap']) ?>"
                                                                    data-nomor_hp="<?= e_attr($user['nomor_hp']) ?>"
                                                                    data-id_role="<?= $user['id_role'] ?>"
                                                                    data-status="<?= $user['is_active'] ?>" data-toggle="modal"
                                                                    data-target="#modalEdit">
                                                                    <i class="fas fa-edit"></i> Edit
                                                                </button>
                                                            </div>
                                                        <?php endif; ?>

                                                        <?php if (Permission::can($pdo, 'Pengguna', 'delete')): ?>
                                                            <form method="POST" action="delete.php" class="form-delete col">
                                                                <?= csrfField() ?>
                                                                <input type="hidden" name="id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-block btn-danger">
                                                                    <i class="fas fa-trash"></i> Delete
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th data-translate="Nama Lengkap">Nama Lengkap</th>
                                                <th data-translate="Username">Username</th>
                                                <th data-translate="Email">Email</th>
                                                <th data-translate="No HP">No HP</th>
                                                <th data-translate="Role">Role</th>
                                                <th data-translate="Status Aktif">Status Aktif</th>
                                                <th data-translate="Aksi">Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>

            <div class="modal fade" id="modalTambah">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" data-translate="Tambah Pengguna">Tambah Pengguna</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form id="formTambah" method="POST" action="store.php">
                            <?= csrfField() ?>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nama_lengkap">Nama Lengkap<code>*</code></label>
                                    <input type="text" name="nama_lengkap" class="form-control" id="nama_lengkap"
                                        placeholder="Masukkan nama lengkap">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email<code>*</code></label>
                                    <input type="email" name="email" class="form-control" id="email"
                                        placeholder="Masukkan email">
                                </div>
                                <div class="form-group">
                                    <label for="nomor_hp">Nomor HP</label>
                                    <input type="number" name="nomor_hp" class="form-control" id="nomor_hp"
                                        placeholder="Masukkan nomor HP">
                                </div>
                                <div class="form-group">
                                    <label for="username">Username<code>*</code></label>
                                    <input type="text" name="username" class="form-control" id="username"
                                        placeholder="Masukkan username">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password<code>*</code></label>
                                    <input type="password" name="password" class="form-control" id="password"
                                        placeholder="Masukkan password">
                                </div>
                                <div class="form-group">
                                    <label for="id_role">Role<code>*</code></label>
                                    <select name="id_role" class="form-control">
                                        <option value="">-- Pilih Role --</option>
                                        <?php foreach ($roles as $r): ?>
                                            <option value="<?= $r['id'] ?>">
                                                <?= htmlspecialchars($r['nama']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Status Aktif <code>*</code></label>
                                    <div class="form-group row">
                                        <div class="col-sm-2">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" id="add_status_aktif"
                                                    name="is_active" value="1" checked>
                                                <label for="add_status_aktif" class="custom-control-label" data-translate="Aktif">Aktif</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio"
                                                    id="add_status_nonaktif" name="is_active" value="0">
                                                <label for="add_status_nonaktif"
                                                    class="custom-control-label" data-translate="Nonaktif">Nonaktif</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" data-translate="Simpan">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modalEdit">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h4 class="modal-title" data-translate="Edit Pengguna">Edit Pengguna</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <form id="formEdit" method="POST" action="update.php">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" id="edit_id">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nama_lengkap">Nama Lengkap<code>*</code></label>
                                    <input type="text" name="nama_lengkap" class="form-control" id="edit_nama_lengkap"
                                        placeholder="Masukkan nama lengkap">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email<code>*</code></label>
                                    <input type="email" name="email" class="form-control" id="edit_email"
                                        placeholder="Masukkan email">
                                </div>
                                <div class="form-group">
                                    <label for="nomor_hp">Nomor HP</label>
                                    <input type="number" name="nomor_hp" class="form-control" id="edit_nomor_hp"
                                        placeholder="Masukkan nomor HP">
                                </div>
                                <div class="form-group">
                                    <label for="username">Username<code>*</code></label>
                                    <input type="text" name="username" class="form-control" id="edit_username"
                                        placeholder="Masukkan username">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" name="password" class="form-control" id="edit_password"
                                        placeholder="Kosongkan jika tidak ingin mengganti password">
                                </div>
                                <div class="form-group">
                                    <label for="edit_id_role">Role<code>*</code></label>
                                    <select name="id_role" class="form-control" id="edit_id_role">
                                        <option value="">-- Pilih Role --</option>
                                        <?php foreach ($roles as $r): ?>
                                            <option value="<?= $r['id'] ?>">
                                                <?= htmlspecialchars($r['nama']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Status Aktif <code>*</code></label>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_aktif" name="is_active" value="1">
                                        <label for="edit_status_aktif" class="custom-control-label" data-translate="Aktif">
                                            Aktif
                                        </label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_nonaktif" name="is_active" value="0">
                                        <label for="edit_status_nonaktif" class="custom-control-label" data-translate="Nonaktif">
                                            Nonaktif
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" data-translate="Update">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include "../feature/footer.php" ?>

        <div aria-live="polite" aria-atomic="true" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
            <div id="toast-container"></div>
        </div>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../assets/adminlte/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="../assets/adminlte/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/jszip/jszip.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../assets/adminlte/dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../assets/adminlte/dist/js/demo.js"></script>
    <!-- jquery-validation -->
    <script src="../assets/adminlte/plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="../assets/adminlte/plugins/jquery-validation/additional-methods.min.js"></script>
    <!-- Page specific script -->
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script>
        $(function() {
            function initValidationTambah(formId) {
                $(formId).validate({
                    rules: {
                        id_role: {
                            required: true
                        },
                        username: {
                            required: true
                        },
                        email: {
                            required: true
                        },
                        password: {
                            required: true
                        },
                        nama_lengkap: {
                            required: true
                        },
                        // nomor_hp: {
                        //     required: true
                        // },
                        is_active: {
                            required: true
                        }
                    },
                    messages: {
                        id_role: {
                            required: "Silahkan pilih Role Pengguna"
                        },
                        username: {
                            required: "Silahkan masukkan Username"
                        },
                        email: {
                            required: "Silahkan masukkan Email"
                        },
                        password: {
                            required: "Silahkan masukkan Password"
                        },
                        nama_lengkap: {
                            required: "Silahkan masukkan Nama Lengkap"
                        },
                        // nomor_hp: {
                        //     required: "Silahkan masukkan Nomor HP"
                        // },
                        is_active: {
                            required: "Silahkan pilih Status Pengguna"
                        }
                    },
                    errorElement: 'span',
                    errorPlacement: function(error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function(element) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function(element) {
                        $(element).removeClass('is-invalid');
                    }
                });
            }

            function initValidationEdit(formId) {
                $(formId).validate({
                    rules: {
                        id_role: {
                            required: true
                        },
                        username: {
                            required: true
                        },
                        email: {
                            required: true
                        },
                        password: {
                            required: false
                        },
                        nama_lengkap: {
                            required: true
                        },
                        // nomor_hp: {
                        //     required: true
                        // },
                        is_active: {
                            required: true
                        }
                    },
                    messages: {
                        id_role: {
                            required: "Silahkan pilih Role Pengguna"
                        },
                        username: {
                            required: "Silahkan masukkan Username"
                        },
                        email: {
                            required: "Silahkan masukkan Email"
                        },
                        password: {
                            required: "Silahkan masukkan Password"
                        },
                        nama_lengkap: {
                            required: "Silahkan masukkan Nama Lengkap"
                        },
                        // nomor_hp: {
                        //     required: "Silahkan masukkan Nomor HP"
                        // },
                        is_active: {
                            required: "Silahkan pilih Status Pengguna"
                        }
                    },
                    errorElement: 'span',
                    errorPlacement: function(error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function(element) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function(element) {
                        $(element).removeClass('is-invalid');
                    }
                });
            }

            initValidationTambah("#formTambah");
            initValidationEdit("#formEdit");
        });
    </script>

    <script>
        $(document).on("click", ".btn-edit", function() {
            let id = $(this).data("id");
            let id_role = $(this).data("id_role");
            let username = $(this).data("username");
            let email = $(this).data("email");
            let nama_lengkap = $(this).data("nama_lengkap");
            let nomor_hp = $(this).data("nomor_hp");
            let status = $(this).data("status");

            $("#edit_id").val(id);
            $("#edit_id_role").val(id_role);
            $("#edit_username").val(username);
            $("#edit_email").val(email);
            $("#edit_nama_lengkap").val(nama_lengkap);
            $("#edit_nomor_hp").val(nomor_hp);
            $("input[name='is_active'][value='" + status + "']").prop("checked", true);
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).on("submit", ".form-delete", function(e) {
            e.preventDefault();
            let form = this;
            Swal.fire({
                title: 'Apakah anda yakin?',
                text: "Data akan dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    </script>

    <script>
        function showToast(message, type) {
            let bgColor = 'bg-success';
            if (type === 'updated') {
                bgColor = 'bg-info';
            } else if (type === 'deleted') {
                bgColor = 'bg-danger';
            }
            $(document).Toasts('create', {
                class: bgColor,
                title: 'Berhasil',
                body: message,
                delay: 1000
            });
        }
        const urlParams = new URLSearchParams(window.location.search);
        const success = urlParams.get('success');
        if (success === "created") {
            showToast("Data Pengguna berhasil ditambahkan", "created");
        }
        if (success === "updated") {
            showToast("Data Pengguna berhasil diperbarui", "updated");
        }
        if (success === "deleted") {
            showToast("Data Pengguna berhasil dihapus", "deleted");
        }
    </script>
</body>

</html>
<?php
require "../../app/core/session.php";
secureSessionStart();
require "../../app/core/csrf.php";
require "../../app/config/database.php";
require "../../app/models/TopografiObservasi.php";
require "../../app/core/permission.php";
require '../../app/core/activity_log.php';

Permission::authorize($pdo, 'Topografi Observasi', 'create');
verifyCsrfToken();

$topografiObservasi = new TopografiObservasi($pdo);

$data = [
    "id_tanah" => $_POST["id_tanah"],
    "periode_pengecekan" => $_POST["periode_pengecekan"],
    "id_lanskap" => $_POST["id_lanskap"],
    "id_fitur_tambahan" => $_POST["id_fitur_tambahan"],
    "elevasi_mdpl" => $_POST["elevasi_mdpl"],
    "kemiringan_derajat" => $_POST["kemiringan_derajat"],
    "rawan_erosi" => $_POST["rawan_erosi"],
    "arah_lereng" => $_POST["arah_lereng"],
    "catatan" => $_POST["catatan"],
    "created_by" => $_SESSION["user_id"]
];

$newId = $topografiObservasi->create($data);

if ($newId) {
    logActivity(
        $pdo,
        'CREATE',
        'Topografi Observasi',
        $newId,
        't_topografi_observasi',
        null,
        $data,
        'Menambahkan data Topografi Observasi',
        'SUCCESS'
    );
}

header("Location: index.php?success=created");
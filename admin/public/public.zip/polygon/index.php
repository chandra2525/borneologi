<?php

require_once '../../app/config/database.php';
require_once '../../app/controllers/PolygonController.php';
require_once '../../app/core/session.php';
require_once '../../app/core/csrf.php';
require_once "../../app/core/auth.php";
require_once '../../app/helpers/escape.php';
require_once "../../app/core/permission.php";

secureSessionStart();
checkAuth("non_dashboard");

$controller = new PolygonController($pdo);
// $polygons = $controller->index();
$hutanAdats = $controller->getHutanAdat();
$provinsis = $controller->getProvinsi();
$kabupatens = $controller->getKabupaten();
$kecamatans = $controller->getKecamatan();
$desas = $controller->getDesa();
$kalekas = $controller->getKaleka();
$hutanLindung = $controller->getHutanLindung();
$hutanProduksiTetap = $controller->getHutanProduksiTetap();
$hutanProduksiTerbatas = $controller->getHutanProduksiTerbatas();
$hutanProduksiKonversi = $controller->getHutanProduksiKonversi();
$kawasanKonservasi = $controller->getKawasanKonservasi();
$areaPenggunaanLain = $controller->getAreaPenggunaanLain();
Permission::authorize($pdo, 'Polygon', 'view');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Borneologi</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/fontawesome-free/css/all.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../assets/adminlte/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include "../feature/navbar.php" ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php
        $menu = "polygon";
        include "../feature/sidebar.php";
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Data Polygon</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Master Data</a></li>
                                <li class="breadcrumb-item active">Data Polygon</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header row">
                                    <h3 class="card-title col-9">Berikut adalah list dari Data Polygon</h3>
                                    <?php if (Permission::can($pdo, 'Polygon', 'create')): ?>
                                        <button class="col-3 btn btn-block btn-success" data-toggle="modal"
                                            data-target="#modalTambah">
                                            Tambah Polygon
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th>Kode Polygon</th>
                                                <th>Nama Polygon</th>
                                                <th>Geometri Area</th>
                                                <th>Relasi Nama</th>
                                                <th>Relasi Tipe</th>
                                                <th>Status Aktif</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th>Kode Polygon</th>
                                                <th>Nama Polygon</th>
                                                <th>Geometri Area</th>
                                                <th>Relasi Nama</th>
                                                <th>Relasi Tipe</th>
                                                <th>Status Aktif</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>

            <div class="modal fade" id="modalTambah">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Tambah Polygon</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form id="formTambah" method="POST" action="store.php" enctype="multipart/form-data">
                            <?= csrfField() ?>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="kode_polygon">Kode Polygon<code>*</code></label>
                                    <input type="text" name="kode_polygon" class="form-control" id="kode_polygon"
                                        value="<?= (new Polygon($pdo))->generateKode() ?>"
                                        placeholder="Masukkan Kode Polygon" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="nama_polygon">Nama Polygon<code>*</code></label>
                                    <input type="text" name="nama_polygon" class="form-control" id="nama_polygon"
                                        placeholder="Masukkan Nama Polygon">
                                </div>
                                <div class="form-group">
                                    <label>Upload Shapefile (.zip) <code>*</code></label>
                                    <input type="file" name="shp_file" class="form-control"
                                        accept=".zip,application/zip,application/x-zip-compressed">
                                    <small class="text-muted">Harus berisi: .shp, .shx, .dbf, .prj</small>
                                </div>
                                <div class="form-group">
                                    <label>Status Aktif<code>*</code></label>
                                    <div class="form-group row">
                                        <div class="col-sm-2">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" id="add_status_aktif"
                                                    name="is_active" value="1" checked>
                                                <label for="add_status_aktif" class="custom-control-label">Aktif</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio"
                                                    id="add_status_nonaktif" name="is_active" value="0">
                                                <label for="add_status_nonaktif"
                                                    class="custom-control-label">Nonaktif</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modalEdit">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h4 class="modal-title">Edit Polygon</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <form id="formEdit" method="POST" action="update.php">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" id="edit_id">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="kode_polygon">Kode Polygon<code>*</code></label>
                                    <input type="text" name="kode_polygon" class="form-control" id="edit_kode_polygon"
                                        value="<?= (new Polygon($pdo))->generateKode() ?>"
                                        placeholder="Masukkan Kode Polygon" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="nama_polygon">Nama Polygon<code>*</code></label>
                                    <input type="text" name="nama_polygon" class="form-control" id="edit_nama_polygon"
                                        placeholder="Masukkan Nama Polygon">
                                </div>
                                <!-- <div class="form-group">
                                    <label>Upload Shapefile (.zip)</label>
                                    <input type="file" name="shp_file" class="form-control" accept=".zip">
                                </div> -->
                                <div class="form-group">
                                    <label>Relasi Tipe<code>*</code></label>
                                    <select name="relasi_tipe" class="form-control" id="edit_relasi_tipe">
                                        <option value="">-- Pilih Relasi --</option>
                                        <option value="hutan_adat">Hutan Adat</option>
                                        <option value="provinsi">Provinsi</option>
                                        <option value="kabupaten">Kabupaten</option>
                                        <option value="kecamatan">Kecamatan</option>
                                        <option value="desa">Desa</option>
                                        <option value="kaleka">Kaleka</option>
                                        <option value="hutan_lindung">Hutan Lindung</option>
                                        <option value="hutan_produksi_tetap">Hutan Produksi Tetap</option>
                                        <option value="hutan_produksi_terbatas">Hutan Produksi Terbatas</option>
                                        <option value="hutan_produksi_konversi">Hutan Produksi yang dapat di Konversi
                                        </option>
                                        <option value="kawasan_konservasi">Kawasan Konservasi (Taman Hutan Raya)
                                        </option>
                                        <option value="area_penggunaan_lain">Area Penggunaan Lain</option>
                                    </select>
                                </div>

                                <div class="form-group" id="group_hutan_adat" style="display:none;">
                                    <label>Hutan Adat<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_hutan_adat" name="hutan_adat">
                                        <option value="">-- Pilih Hutan Adat --</option>
                                        <?php foreach ($hutanAdats as $hA): ?>
                                            <option value="<?= $hA['id'] ?>">
                                                <?= htmlspecialchars($hA['nama_hutan_adat']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_provinsi" style="display:none;">
                                    <label>Provinsi<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_provinsi" name="provinsi">
                                        <option value="">-- Pilih Provinsi --</option>
                                        <?php foreach ($provinsis as $p): ?>
                                            <option value="<?= $p['id'] ?>">
                                                <?= htmlspecialchars($p['nama_provinsi']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_kabupaten" style="display:none;">
                                    <label>Kabupaten<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_kabupaten" name="kabupaten">
                                        <option value="">-- Pilih Kabupaten --</option>
                                        <?php foreach ($kabupatens as $k): ?>
                                            <option value="<?= $k['id'] ?>">
                                                <?= htmlspecialchars($k['nama_kabupaten']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_kecamatan" style="display:none;">
                                    <label>Kecamatan<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_kecamatan" name="kecamatan">
                                        <option value="">-- Pilih Kecamatan --</option>
                                        <?php foreach ($kecamatans as $k): ?>
                                            <option value="<?= $k['id'] ?>">
                                                <?= htmlspecialchars($k['nama_kecamatan']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_desa" style="display:none;">
                                    <label>Desa<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_desa" name="desa">
                                        <option value="">-- Pilih Desa --</option>
                                        <?php foreach ($desas as $d): ?>
                                            <option value="<?= $d['id'] ?>">
                                                <?= htmlspecialchars($d['nama_desa']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_kaleka" style="display:none;">
                                    <label>Kaleka<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_kaleka" name="kaleka">
                                        <option value="">-- Pilih Kaleka --</option>
                                        <?php foreach ($kalekas as $k): ?>
                                            <option value="<?= $k['id'] ?>">
                                                <?= htmlspecialchars($k['nama_kaleka']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_hutan_lindung" style="display:none;">
                                    <label>Hutan Lindung<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_hutan_lindung"
                                        name="hutan_lindung">
                                        <option value="">-- Pilih Hutan Lindung --</option>
                                        <?php foreach ($hutanLindung as $hl): ?>
                                            <option value="<?= $hl['id'] ?>">
                                                <?= htmlspecialchars($hl['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_hutan_produksi_tetap" style="display:none;">
                                    <label>Hutan Produksi Tetap<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_hutan_produksi_tetap"
                                        name="hutan_produksi_tetap">
                                        <option value="">-- Pilih Hutan Produksi Tetap --</option>
                                        <?php foreach ($hutanProduksiTetap as $hp): ?>
                                            <option value="<?= $hp['id'] ?>">
                                                <?= htmlspecialchars($hp['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_hutan_produksi_terbatas" style="display:none;">
                                    <label>Hutan Produksi Terbatas<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_hutan_produksi_terbatas"
                                        name="hutan_produksi_terbatas">
                                        <option value="">-- Pilih Hutan Produksi Terbatas --</option>
                                        <?php foreach ($hutanProduksiTerbatas as $hpt): ?>
                                            <option value="<?= $hpt['id'] ?>">
                                                <?= htmlspecialchars($hpt['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_hutan_produksi_konversi" style="display:none;">
                                    <label>Hutan Produksi yang dapat di Konversi<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_hutan_produksi_konversi"
                                        name="hutan_produksi_konversi">
                                        <option value="">-- Pilih Hutan Produksi yang dapat di Konversi --</option>
                                        <?php foreach ($hutanProduksiKonversi as $hpk): ?>
                                            <option value="<?= $hpk['id'] ?>">
                                                <?= htmlspecialchars($hpk['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_kawasan_konservasi" style="display:none;">
                                    <label>Kawasan Konservasi (Taman Hutan Raya)<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_kawasan_konservasi"
                                        name="kawasan_konservasi">
                                        <option value="">-- Pilih Kawasan Konservasi (Taman Hutan Raya) --</option>
                                        <?php foreach ($kawasanKonservasi as $kk): ?>
                                            <option value="<?= $kk['id'] ?>">
                                                <?= htmlspecialchars($kk['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="form-group" id="group_area_penggunaan_lain" style="display:none;">
                                    <label>Area Penggunaan Lain<code>*</code></label>
                                    <select class="form-control relasi-dropdown" id="edit_area_penggunaan_lain"
                                        name="area_penggunaan_lain">
                                        <option value="">-- Pilih Area Penggunaan Lain --</option>
                                        <?php foreach ($areaPenggunaanLain as $apl): ?>
                                            <option value="<?= $apl['id'] ?>">
                                                <?= htmlspecialchars($apl['tipe_area']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <!-- hidden untuk dikirim ke backend -->
                                <input type="hidden" name="relasi_id" id="edit_relasi_id">

                                <div class="form-group">
                                    <label>Status Aktif <code>*</code></label>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_aktif" name="is_active" value="1">
                                        <label for="edit_status_aktif" class="custom-control-label">
                                            Aktif
                                        </label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_nonaktif" name="is_active" value="0">
                                        <label for="edit_status_nonaktif" class="custom-control-label">
                                            Nonaktif
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modalGeom">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Data Geometri Area</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <div class="modal-body" id="geom_content">
                            <!-- isi dari JS -->
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include "../feature/footer.php" ?>

        <div aria-live="polite" aria-atomic="true" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
            <div id="toast-container"></div>
        </div>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../assets/adminlte/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="../assets/adminlte/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/jszip/jszip.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../assets/adminlte/dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../assets/adminlte/dist/js/demo.js"></script>
    <!-- jquery-validation -->
    <script src="../assets/adminlte/plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="../assets/adminlte/plugins/jquery-validation/additional-methods.min.js"></script>
    <!-- Page specific script -->
    <script>
        $(function() {
            $("#example1").DataTable({

                    processing: true,

                    serverSide: true,

                    ajax: {
                        url: "api.php",
                        type: "GET",
                        error: function(xhr) {
                            console.error("API Error:", xhr.responseText);
                            try {

                                const response = JSON.parse(xhr.responseText);

                                if (response.error) {
                                    console.error("Server Error:", response.error);
                                }

                            } catch (e) {

                                console.error(
                                    "Response bukan JSON:",
                                    xhr.responseText
                                );
                            }
                        }
                    },

                    responsive: true,

                    lengthChange: true,

                    pageLength: 10,

                    lengthMenu: [
                        [10, 25, 50, 100],
                        [10, 25, 50, 100]
                    ],

                    autoWidth: false,

                    order: [
                        [0, "asc"]
                    ],

                    columns: [

                        // NO
                        {
                            data: null,
                            searchable: false,
                            orderable: false,

                            render: function(data, type, row, meta) {

                                return meta.settings._iDisplayStart +
                                    meta.row +
                                    1;
                            }
                        },


                        // KODE POLYGON
                        {
                            data: "kode_polygon"
                        },


                        // NAMA POLYGON
                        {
                            data: "nama_polygon"
                        },


                        // GEOMETRI AREA
                        {
                            data: "geom_area",

                            searchable: false,

                            orderable: false,

                            render: function(data, type, row) {

                                return `
                    <button
                        type="button"
                        class="btn btn-block btn-primary btn-geom"
                        data-id="${row.id}"
                        data-toggle="modal"
                        data-target="#modalGeom">

                        <i class="fas fa-list"></i>
                        Lihat

                    </button>
                `;
                            }
                        },


                        // RELASI NAMA
                        {
                            data: "relasi_nama"
                        },


                        // RELASI TIPE
                        {
                            data: "relasi_tipe",

                            render: function(data) {

                                return getRelasiTipeLabel(data);
                            }
                        },


                        // STATUS
                        {
                            data: "is_active",

                            render: function(data) {

                                return parseInt(data) === 1 ?
                                    "Aktif" :
                                    "Nonaktif";
                            }
                        },


                        // AKSI
                        {
                            data: null,

                            searchable: false,

                            orderable: false,

                            render: function(data, type, row) {

                                return `
                                    <div class="row">
                                        <?php if (Permission::can($pdo, 'Polygon', 'update')): ?>
                                        <div class="col">
                                            <button
                                                type="button"
                                                class="btn btn-block btn-info btn-edit"

                                                data-id="${row.id}"

                                                data-kode_polygon="${escapeHtml(row.kode_polygon)}"

                                                data-nama_polygon="${escapeHtml(row.nama_polygon)}"

                                                data-relasi_id="${row.relasi_id}"

                                                data-relasi_tipe="${row.relasi_tipe}"

                                                data-status="${row.is_active}"

                                                data-toggle="modal"
                                                data-target="#modalEdit">

                                                <i class="fas fa-edit"></i>
                                                Edit

                                            </button>
                                        </div>
                                        <?php endif; ?>

                                        <?php if (Permission::can($pdo, 'Polygon', 'delete')): ?>
                                        <form
                                            method="POST"
                                            action="delete.php"
                                            class="form-delete col">

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="${row.id}">

                                            <button
                                                type="submit"
                                                class="btn btn-block btn-danger">

                                                <i class="fas fa-trash"></i>
                                                Hapus

                                            </button>

                                        </form>
                                        <?php endif; ?>
                                    </div>
                                `;
                            }
                        }

                    ],


                    buttons: [
                        "copy",
                        "csv",
                        "excel",
                        "pdf",
                        "print",
                        "colvis"
                    ]

                })
                .buttons()
                .container()
                .appendTo('#example1_wrapper .col-md-6:eq(0)');
            $("#example1").on("error.dt", function(e, settings, techNote, message) {
                console.error("DataTables Error:", message);
            });
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });

        function escapeHtml(value) {
            if (value === null || value === undefined) {
                return '';
            }
            return String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        function getRelasiTipeLabel(tipe) {

            switch (tipe) {

                case 'provinsi':
                    return 'Provinsi';

                case 'kabupaten':
                    return 'Kabupaten';

                case 'kecamatan':
                    return 'Kecamatan';

                case 'desa':
                    return 'Desa';

                case 'hutan_adat':
                    return 'Hutan Adat';

                case 'kaleka':
                    return 'Kaleka';

                case 'hutan_lindung':
                    return 'Hutan Lindung';

                case 'hutan_produksi_tetap':
                    return 'Hutan Produksi Tetap';

                case 'hutan_produksi_terbatas':
                    return 'Hutan Produksi Terbatas';

                case 'hutan_produksi_konversi':
                    return 'Hutan Produksi yang dapat di Konversi';

                case 'kawasan_konservasi':
                    return 'Kawasan Konservasi (Taman Hutan Raya)';

                case 'area_penggunaan_lain':
                    return 'Area Penggunaan Lain';

                case 'tanpa_relasi':
                    return 'Tanpa Relasi';

                default:
                    return 'Lainnya';
            }
        }
    </script>

    <script>
        $(function() {
            function initValidation(formId) {
                $(formId).validate({
                    rules: {
                        kode_polygon: {
                            required: true
                        },
                        nama_polygon: {
                            required: true
                        },
                        relasi_tipe: {
                            required: true
                        },
                        relasi_id: {
                            required: true
                        },
                        is_active: {
                            required: true
                        }
                    },
                    messages: {
                        kode_polygon: {
                            required: "Silahkan masukkan Kode Polygon"
                        },
                        nama_polygon: {
                            required: "Silahkan masukkan Nama Polygon"
                        },
                        relasi_tipe: {
                            required: "Silahkan pilih Relasi Tipe"
                        },
                        relasi_id: {
                            required: "Silahkan pilih data relasi"
                        },
                        is_active: {
                            required: "Silahkan pilih Status Aktif"
                        }
                    },
                    errorElement: 'span',
                    errorPlacement: function(error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function(element) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function(element) {
                        $(element).removeClass('is-invalid');
                    }
                });
            }
            initValidation("#formTambah");
            initValidation("#formEdit");

            let validator = $("#formEdit").validate();

            // dynamic rules
            $("#edit_hutan_adat").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "hutan_adat";
                },
                messages: {
                    required: "Silahkan pilih Hutan Adat"
                }
            });

            $("#edit_provinsi").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "provinsi";
                },
                messages: {
                    required: "Silahkan pilih Provinsi"
                }
            });

            $("#edit_kabupaten").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "kabupaten";
                },
                messages: {
                    required: "Silahkan pilih Kabupaten"
                }
            });

            $("#edit_kecamatan").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "kecamatan";
                },
                messages: {
                    required: "Silahkan pilih Kecamatan"
                }
            });

            $("#edit_desa").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "desa";
                },
                messages: {
                    required: "Silahkan pilih Desa"
                }
            });

            $("#edit_kaleka").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "kaleka";
                },
                messages: {
                    required: "Silahkan pilih Kaleka"
                }
            });

            $("#edit_hutan_lindung").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "hutan_lindung";
                },
                messages: {
                    required: "Silahkan pilih Hutan Lindung"
                }
            });

            $("#edit_hutan_produksi_tetap").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "hutan_produksi_tetap";
                },
                messages: {
                    required: "Silahkan pilih Hutan Produksi Tetap"
                }
            });

            $("#edit_hutan_produksi_terbatas").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "hutan_produksi_terbatas";
                },
                messages: {
                    required: "Silahkan pilih Hutan Produksi Terbatas"
                }
            });

            $("#edit_hutan_produksi_konversi").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "hutan_produksi_konversi";
                },
                messages: {
                    required: "Silahkan pilih Hutan Produksi yang dapat di Konversi"
                }
            });

            $("#edit_kawasan_konservasi").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "kawasan_konservasi";
                },
                messages: {
                    required: "Silahkan pilih Kawasan Konservasi (Taman Hutan Raya)"
                }
            });

            $("#edit_area_penggunaan_lain").rules("add", {
                required: function() {
                    return $("#edit_relasi_tipe").val() === "area_penggunaan_lain";
                },
                messages: {
                    required: "Silahkan pilih Area Penggunaan Lain"
                }
            });

        });
    </script>

    <script>
        $(document).on("click", ".btn-edit", function() {
            let id = $(this).data("id");
            let kode_polygon = $(this).data("kode_polygon");
            let nama_polygon = $(this).data("nama_polygon");
            // let geom_area = $(this).data("geom_area");
            let relasi_id = $(this).data("relasi_id");
            let relasi_tipe = $(this).data("relasi_tipe");
            let status = $(this).data("status");

            $("#edit_id").val(id);
            $("#edit_kode_polygon").val(kode_polygon);
            $("#edit_nama_polygon").val(nama_polygon);
            $("input[name='is_active'][value='" + status + "']").prop("checked", true);

            // set relasi tipe
            $("#edit_relasi_tipe").val(relasi_tipe).trigger("change");

            // delay biar dropdown muncul dulu
            setTimeout(() => {
                if (relasi_tipe === "hutan_adat") {
                    $("#edit_hutan_adat").val(relasi_id);
                } else if (relasi_tipe === "provinsi") {
                    $("#edit_provinsi").val(relasi_id);
                } else if (relasi_tipe === "kabupaten") {
                    $("#edit_kabupaten").val(relasi_id);
                } else if (relasi_tipe === "kecamatan") {
                    $("#edit_kecamatan").val(relasi_id);
                } else if (relasi_tipe === "desa") {
                    $("#edit_desa").val(relasi_id);
                } else if (relasi_tipe === "kaleka") {
                    $("#edit_kaleka").val(relasi_id);
                } else if (relasi_tipe === "hutan_lindung") {
                    $("#edit_hutan_lindung").val(relasi_id);
                } else if (relasi_tipe === "hutan_produksi_tetap") {
                    $("#edit_hutan_produksi_tetap").val(relasi_id);
                } else if (relasi_tipe === "hutan_produksi_terbatas") {
                    $("#edit_hutan_produksi_terbatas").val(relasi_id);
                } else if (relasi_tipe === "hutan_produksi_konversi") {
                    $("#edit_hutan_produksi_konversi").val(relasi_id);
                } else if (relasi_tipe === "kawasan_konservasi") {
                    $("#edit_kawasan_konservasi").val(relasi_id);
                } else if (relasi_tipe === "area_penggunaan_lain") {
                    $("#edit_area_penggunaan_lain").val(relasi_id);
                }

                $("#edit_relasi_id").val(relasi_id);
            }, 200);
        });

        // saat relasi tipe berubah
        $("#edit_relasi_tipe").on("change", function() {
            let tipe = $(this).val();

            $("#group_hutan_adat").hide();
            $("#group_provinsi").hide();
            $("#group_kabupaten").hide();
            $("#group_kecamatan").hide();
            $("#group_desa").hide();
            $("#group_kaleka").hide();
            $("#group_hutan_lindung").hide();
            $("#group_hutan_produksi_tetap").hide();
            $("#group_hutan_produksi_terbatas").hide();
            $("#group_hutan_produksi_konversi").hide();
            $("#group_kawasan_konservasi").hide();
            $("#group_area_penggunaan_lain").hide();

            // reset value
            $("#edit_relasi_id").val("");
            $("#edit_hutan_adat").val("");
            $("#edit_provinsi").val("");
            $("#edit_kabupaten").val("");
            $("#edit_kecamatan").val("");
            $("#edit_desa").val("");
            $("#edit_kaleka").val("");
            $("#edit_hutan_lindung").val("");
            $("#edit_hutan_produksi_tetap").val("");
            $("#edit_hutan_produksi_terbatas").val("");
            $("#edit_hutan_produksi_konversi").val("");
            $("#edit_kawasan_konservasi").val("");
            $("#edit_area_penggunaan_lain").val("");

            // reset required
            $("#edit_hutan_adat").prop("required", false);
            $("#edit_provinsi").prop("required", false);
            $("#edit_kabupaten").prop("required", false);
            $("#edit_kecamatan").prop("required", false);
            $("#edit_desa").prop("required", false);
            $("#edit_kaleka").prop("required", false);
            $("#edit_hutan_lindung").prop("required", false);
            $("#edit_hutan_produksi_tetap").prop("required", false);
            $("#edit_hutan_produksi_terbatas").prop("required", false);
            $("#edit_hutan_produksi_konversi").prop("required", false);
            $("#edit_kawasan_konservasi").prop("required", false);
            $("#edit_area_penggunaan_lain").prop("required", false);

            if (tipe === "hutan_adat") {
                $("#group_hutan_adat").show();
                $("#edit_hutan_adat").prop("required", true);
            } else if (tipe === "provinsi") {
                $("#group_provinsi").show();
                $("#edit_provinsi").prop("required", true);
            } else if (tipe === "kabupaten") {
                $("#group_kabupaten").show();
                $("#edit_kabupaten").prop("required", true);
            } else if (tipe === "kecamatan") {
                $("#group_kecamatan").show();
                $("#edit_kecamatan").prop("required", true);
            } else if (tipe === "desa") {
                $("#group_desa").show();
                $("#edit_desa").prop("required", true);
            } else if (tipe === "kaleka") {
                $("#group_kaleka").show();
                $("#edit_kaleka").prop("required", true);
            } else if (tipe === "hutan_lindung") {
                $("#group_hutan_lindung").show();
                $("#edit_hutan_lindung").prop("required", true);
            } else if (tipe === "hutan_produksi_tetap") {
                $("#group_hutan_produksi_tetap").show();
                $("#edit_hutan_produksi_tetap").prop("required", true);
            } else if (tipe === "hutan_produksi_terbatas") {
                $("#group_hutan_produksi_terbatas").show();
                $("#edit_hutan_produksi_terbatas").prop("required", true);
            } else if (tipe === "hutan_produksi_konversi") {
                $("#group_hutan_produksi_konversi").show();
                $("#edit_hutan_produksi_konversi").prop("required", true);
            } else if (tipe === "kawasan_konservasi") {
                $("#group_kawasan_konservasi").show();
                $("#edit_kawasan_konservasi").prop("required", true);
            } else if (tipe === "area_penggunaan_lain") {
                $("#group_area_penggunaan_lain").show();
                $("#edit_area_penggunaan_lain").prop("required", true);
            }
        });

        // set relasi_id dari dropdown aktif
        $(".relasi-dropdown").on("change", function() {
            let val = $(this).val();
            $("#edit_relasi_id").val(val);
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).on("submit", ".form-delete", function(e) {
            e.preventDefault();
            let form = this;
            Swal.fire({
                title: 'Apakah anda yakin?',
                text: "Data akan dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    </script>

    <script>
        function showToast(message, type) {
            let bgColor = 'bg-success';
            if (type === 'updated') {
                bgColor = 'bg-info';
            } else if (type === 'deleted') {
                bgColor = 'bg-danger';
            }
            $(document).Toasts('create', {
                class: bgColor,
                title: 'Berhasil',
                body: message,
                delay: 1000
            });
        }
        const urlParams = new URLSearchParams(window.location.search);
        const success = urlParams.get('success');
        if (success === "created") {
            showToast("Data Polygon berhasil ditambahkan", "created");
        }
        if (success === "updated") {
            showToast("Data Polygon berhasil diperbarui", "updated");
        }
        if (success === "deleted") {
            showToast("Data Polygon berhasil dihapus", "deleted");
        }
    </script>

    <script>
        $(document).on("click", ".btn-geom", function() {
            let wkt = $(this).data("geom");

            if (!wkt) {
                $("#geom_content").html("<p>Tidak ada data</p>");
                return;
            }

            // bersihkan MULTIPOLYGON
            wkt = wkt.replace(/MULTIPOLYGON\s*\(\(\(/, '').replace(/\)\)\)/, '');

            let points = wkt.split(',');

            // hapus titik terakhir (duplikat)
            if (points.length > 1) {
                points.pop();
            }

            let html = `
                <table class="table table-bordered table-striped">
                    <tr>
                        <th>No</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                    </tr>
            `;

            points.forEach((p, i) => {
                let coord = p.trim().split(' ');

                if (coord.length === 2) {
                    let lng = coord[0];
                    let lat = coord[1];

                    html += `
                <tr>
                    <td>${i + 1}</td>
                    <td><span class="badge badge-success">${lat}</span></td>
                    <td><span class="badge badge-primary">${lng}</span></td>
                </tr>
            `;
                }
            });

            html += '</table>';

            $("#geom_content").html(html);
        });
    </script>

</body>

</html>
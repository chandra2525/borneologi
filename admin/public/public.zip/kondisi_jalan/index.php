<?php

require_once '../../app/config/database.php';
require_once '../../app/controllers/KondisiJalanController.php';
require_once '../../app/core/session.php';
require_once '../../app/core/csrf.php';
require_once "../../app/core/auth.php";
require_once '../../app/helpers/escape.php';
require_once "../../app/core/permission.php";

secureSessionStart();
checkAuth("non_dashboard");

$controller = new KondisiJalanController($pdo);
$kondisiJalans = $controller->index();
Permission::authorize($pdo, 'Kondisi Jalan', 'view');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Borneologi</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/fontawesome-free/css/all.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/adminlte/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../assets/adminlte/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include "../feature/navbar.php" ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php
        $menu = "kondisi_jalan";
        include "../feature/sidebar.php";
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Data Kondisi Jalan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Master Data</a></li>
                                <li class="breadcrumb-item active">Data Kondisi Jalan</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header row">
                                    <h3 class="card-title col-9">Berikut adalah list dari Data Kondisi Jalan</h3>
                                    <?php if (Permission::can($pdo, 'Kondisi Jalan', 'create')): ?>
                                        <button class="col-3 btn btn-block btn-success" data-toggle="modal"
                                            data-target="#modalTambah">
                                            Tambah Kondisi Jalan
                                        </button>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th>Kode Kondisi Jalan</th>
                                                <th>Nama Kondisi Jalan</th>
                                                <th>Deskripsi</th>
                                                <th>Urutan</th>
                                                <th>Status Aktif</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1; ?>
                                            <?php foreach ($kondisiJalans as $kondisiJalan): ?>
                                                <tr>
                                                    <td class="text-center"><?= $no++ ?></td>
                                                    <td><?= htmlspecialchars($kondisiJalan['kode']) ?></td>
                                                    <td><?= htmlspecialchars($kondisiJalan['nama']) ?></td>
                                                    <td><?= htmlspecialchars($kondisiJalan['deskripsi']) ?></td>
                                                    <td><?= htmlspecialchars($kondisiJalan['urutan']) ?></td>
                                                    <td><?= $kondisiJalan['is_active'] ? 'Aktif' : 'Nonaktif' ?></td>
                                                    <td class="row">
                                                        <?php if (Permission::can($pdo, 'Kondisi Jalan', 'update')): ?>
                                                            <div class="col">
                                                                <button class="btn btn-block btn-info btn-edit"
                                                                    data-id="<?= $kondisiJalan['id'] ?>"
                                                                    data-kode="<?= htmlspecialchars($kondisiJalan['kode']) ?>"
                                                                    data-nama="<?= htmlspecialchars($kondisiJalan['nama']) ?>"
                                                                    data-deskripsi="<?= htmlspecialchars($kondisiJalan['deskripsi']) ?>"
                                                                    data-urutan="<?= $kondisiJalan['urutan'] ?>"
                                                                    data-status="<?= $kondisiJalan['is_active'] ?>"
                                                                    data-toggle="modal" data-target="#modalEdit">
                                                                    <i class="fas fa-edit"></i> Edit
                                                                </button>
                                                            </div>
                                                        <?php endif; ?>

                                                        <?php if (Permission::can($pdo, 'Kondisi Jalan', 'delete')): ?>
                                                            <form method="POST" action="delete.php" class="form-delete col">
                                                                <?= csrfField() ?>
                                                                <input type="hidden" name="id"
                                                                    value="<?= $kondisiJalan['id'] ?>">
                                                                <button type="submit" class="btn btn-block btn-danger">
                                                                    <i class="fas fa-trash"></i> Hapus
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th class="text-center">No</th>
                                                <th>Kode Kondisi Jalan</th>
                                                <th>Nama Kondisi Jalan</th>
                                                <th>Deskripsi</th>
                                                <th>Urutan</th>
                                                <th>Status Aktif</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>

            <div class="modal fade" id="modalTambah">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Tambah Kondisi Jalan</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form id="formTambah" method="POST" action="store.php">
                            <?= csrfField() ?>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="kode">Kode Kondisi Jalan<code>*</code></label>
                                    <input type="text" name="kode" class="form-control" id="kode"
                                        value="<?= (new KondisiJalan($pdo))->generateKode() ?>"
                                        placeholder="Masukkan kode kondisi jalan" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama Kondisi Jalan<code>*</code></label>
                                    <input type="text" name="nama" class="form-control" id="nama"
                                        placeholder="Masukkan nama kondisi jalan">
                                </div>
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi</label>
                                    <textarea type="text" name="deskripsi" class="form-control" id="deskripsi"
                                        placeholder="Masukkan deskripsi"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="urutan">Urutan<code>*</code></label>
                                    <input type="number" name="urutan" class="form-control" id="urutan"
                                        value="<?= (new KondisiJalan($pdo))->generateUrutan() ?>" placeholder="Masukkan urutan">
                                </div>
                                <div class="form-group">
                                    <label>Status Aktif <code>*</code></label>
                                    <div class="form-group row">
                                        <div class="col-sm-2">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" id="add_status_aktif"
                                                    name="is_active" value="1" checked>
                                                <label for="add_status_aktif" class="custom-control-label">Aktif</label>
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio"
                                                    id="add_status_nonaktif" name="is_active" value="0">
                                                <label for="add_status_nonaktif"
                                                    class="custom-control-label">Nonaktif</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="modalEdit">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h4 class="modal-title">Edit Kondisi Jalan</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <form id="formEdit" method="POST" action="update.php">
                            <?= csrfField() ?>
                            <input type="hidden" name="id" id="edit_id">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="kode">Kode Kondisi Jalan<code>*</code></label>
                                    <input type="text" name="kode" id="edit_kode" class="form-control" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama Kondisi Jalan<code>*</code></label>
                                    <input type="text" name="nama" id="edit_nama" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Deskripsi</label>
                                    <textarea name="deskripsi" id="edit_deskripsi" class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="urutan">Urutan<code>*</code></label>
                                    <input type="number" name="urutan" id="edit_urutan" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Status Aktif <code>*</code></label>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_aktif" name="is_active" value="1">
                                        <label for="edit_status_aktif" class="custom-control-label">
                                            Aktif
                                        </label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input class="custom-control-input edit_status" type="radio"
                                            id="edit_status_nonaktif" name="is_active" value="0">
                                        <label for="edit_status_nonaktif" class="custom-control-label">
                                            Nonaktif
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php include "../feature/footer.php" ?>

        <div aria-live="polite" aria-atomic="true" style="position: fixed; top: 20px; right: 20px; z-index: 9999;">
            <div id="toast-container"></div>
        </div>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="../assets/adminlte/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="../assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="../assets/adminlte/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="../assets/adminlte/plugins/jszip/jszip.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="../assets/adminlte/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="../assets/adminlte/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../assets/adminlte/dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../assets/adminlte/dist/js/demo.js"></script>
    <!-- jquery-validation -->
    <script src="../assets/adminlte/plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="../assets/adminlte/plugins/jquery-validation/additional-methods.min.js"></script>
    <!-- Page specific script -->
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script>
        $(function() {
            function initValidation(formId) {
                $(formId).validate({
                    rules: {
                        kode: {
                            required: true
                        },
                        nama: {
                            required: true
                        },
                        urutan: {
                            required: true
                        },
                        is_active: {
                            required: true
                        }
                    },
                    messages: {
                        kode: {
                            required: "Silahkan masukkan Kode Kondisi Jalan"
                        },
                        nama: {
                            required: "Silahkan masukkan Nama Kondisi Jalan"
                        },
                        urutan: {
                            required: "Silahkan masukkan Urutan"
                        },
                        is_active: {
                            required: "Silahkan pilih Status Kondisi Jalan"
                        }
                    },
                    errorElement: 'span',
                    errorPlacement: function(error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function(element) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function(element) {
                        $(element).removeClass('is-invalid');
                    }
                });
            }
            initValidation("#formTambah");
            initValidation("#formEdit");
        });
    </script>

    <script>
        $(document).on("click", ".btn-edit", function() {
            let id = $(this).data("id");
            let kode = $(this).data("kode");
            let nama = $(this).data("nama");
            let deskripsi = $(this).data("deskripsi");
            let urutan = $(this).data("urutan");
            let status = $(this).data("status");
            let mha = $(this).data("mha");

            $("#edit_id").val(id);
            $("#edit_kode").val(kode);
            $("#edit_nama").val(nama);
            $("#edit_deskripsi").val(deskripsi);
            $("#edit_urutan").val(urutan);
            $("input[name='is_active'][value='" + status + "']").prop("checked", true);
            $("#edit_is_mha").prop("checked", mha == 1);
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).on("submit", ".form-delete", function(e) {
            e.preventDefault();
            let form = this;
            Swal.fire({
                title: 'Apakah anda yakin?',
                text: "Data akan dihapus!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    </script>

    <script>
        function showToast(message, type) {
            let bgColor = 'bg-success';
            if (type === 'updated') {
                bgColor = 'bg-info';
            } else if (type === 'deleted') {
                bgColor = 'bg-danger';
            }
            $(document).Toasts('create', {
                class: bgColor,
                title: 'Berhasil',
                body: message,
                delay: 1000
            });
        }
        const urlParams = new URLSearchParams(window.location.search);
        const success = urlParams.get('success');
        if (success === "created") {
            showToast("Data Kondisi Jalan berhasil ditambahkan", "created");
        }
        if (success === "updated") {
            showToast("Data Kondisi Jalan berhasil diperbarui", "updated");
        }
        if (success === "deleted") {
            showToast("Data Kondisi Jalan berhasil dihapus", "deleted");
        }
    </script>
</body>

</html>